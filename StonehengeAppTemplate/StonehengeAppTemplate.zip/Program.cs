﻿using IctBaden.Stonehenge;

namespace StonehengeApp
{
  static class Program
  {
    public static AppEngine App;
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    static void Main()
    {
      App = new AppEngine("$projectname$", "start");
      App.Run(true);
    }
  }
}
